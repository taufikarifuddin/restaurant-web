<?php

namespace app\models;

class EmiterModel{

    const SUBMIT_ORDER = "submit-order";
    const SEND_BACK_TO_USER = "send-back-to-user";
    const SUBMIT_TO_CHEF = "submit-to-chef";
    const NOTIFY_PROGRESS ="notify-progress";
}