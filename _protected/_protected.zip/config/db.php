<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=db_resto',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
