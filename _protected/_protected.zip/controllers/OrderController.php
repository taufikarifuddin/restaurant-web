<?php

namespace app\controllers;

use Yii;
use app\models\Order;
use app\models\OrderSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * OrderController implements the CRUD actions for Order model.
 */
class OrderController extends Controller
{
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all Order models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new OrderSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Order model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $model = $this->findModel($id);
        $providerOrderItem = new \yii\data\ArrayDataProvider([
            'allModels' => $model->orderItems,
        ]);
        return $this->render('view', [
            'model' => $this->findModel($id),
            'providerOrderItem' => $providerOrderItem,
        ]);
    }

    /**
     * Creates a new Order model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Order();

        if ($model->loadAll(Yii::$app->request->post()) && $model->saveAll()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing Order model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->loadAll(Yii::$app->request->post()) && $model->saveAll()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Order model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->deleteWithRelated();

        return $this->redirect(['index']);
    }
    
    /**
     * 
     * Export Order information into PDF format.
     * @param integer $id
     * @return mixed
     */
    public function actionPdf($id) {
        $model = $this->findModel($id);
        $providerOrderItem = new \yii\data\ArrayDataProvider([
            'allModels' => $model->orderItems,
        ]);

        $content = $this->renderAjax('_pdf', [
            'model' => $model,
            'providerOrderItem' => $providerOrderItem,
        ]);

        $pdf = new \kartik\mpdf\Pdf([
            'mode' => \kartik\mpdf\Pdf::MODE_CORE,
            'format' => \kartik\mpdf\Pdf::FORMAT_A4,
            'orientation' => \kartik\mpdf\Pdf::ORIENT_PORTRAIT,
            'destination' => \kartik\mpdf\Pdf::DEST_BROWSER,
            'content' => $content,
            'cssFile' => '@vendor/kartik-v/yii2-mpdf/assets/kv-mpdf-bootstrap.min.css',
            'cssInline' => '.kv-heading-1{font-size:18px}',
            'options' => ['title' => \Yii::$app->name],
            'methods' => [
                'SetHeader' => [\Yii::$app->name],
                'SetFooter' => ['{PAGENO}'],
            ]
        ]);

        return $pdf->render();
    }

    
    /**
     * Finds the Order model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Order the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Order::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
    
    /**
    * Action to load a tabular form grid
    * for OrderItem
    * @author Yohanes Candrajaya <moo.tensai@gmail.com>
    * @author Jiwantoro Ndaru <jiwanndaru@gmail.com>
    *
    * @return mixed
    */
    public function actionAddOrderItem()
    {
        if (Yii::$app->request->isAjax) {
            $row = Yii::$app->request->post('OrderItem');
            if((Yii::$app->request->post('isNewRecord') && Yii::$app->request->post('_action') == 'load' && empty($row)) || Yii::$app->request->post('_action') == 'add')
                $row[] = [];
            return $this->renderAjax('_formOrderItem', ['row' => $row]);
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    public function actionGetOrderCashier(){
        $post = Yii::$app->request->post();
        if( $post && Yii::$app->request->isAjax ){
            $order = Order::findOne($post['order']);
            
            if( is_null($order) ) return "";

            $str = '<tr id="container-'.$order->id.'">
                <td> ORD-'.$order->id.' </td>    
                <td> '.$order->user->username.' </td>    
                <td> '.$order->table_number.' </td>    
                <td>
                    <table class="table" id="table-'.$order->id.'">
                        <tr>
                            <td style="width:15%;"> Food Name </td>
                            <td style="width:5%;"> Qty </td>                              
                        </tr>';
            foreach( $order->orderItems as $k => $v ){
                $str .= "<tr>
                    <td>".$v->food->name."</td>
                    <td>".$v->qty."</td>  
                    <td> 
                        <div class='form-group'>
                            <input type='checkbox' checked='checked'  id='checkbox-".$v->id."' data-parent='".$order->id."'
                            data-id='".$v->id."' class='checkbox-".$order->id." checkbox' id='item-".$v->id."' />
                        </div>
                        <div class='form-group'>                  
                            <textarea class='textarea' id='textarea-".$v->id."' style='display:none;' 
                                placeholder='Add Note' rows=4 cols=80 id='note-".$v->id."'></textarea>
                        </div>
                    </td>                        
                </tr>";
            }

            $str .='</table>
                </td>                
                <td>
                    <button id="btn-approve-'.$order->id.'"  data-id="'.$order->id.'"  class="btn-approve btn btn-success btn-flat btn-xs round">
                        <i class="fa fa-check"></i>
                    </button>
                    <button id="btn-reject-'.$order->id.'" data-id="'.$order->id.'" disabled class="btn-reject btn btn-danger btn-flat btn-xs">
                        <i class="fa fa-times"></i>                    
                    </button>    
                </td>
            </tr>';

            return $str;

        }

        return "";
    }

    public function actionGetOrderChef(){
        $post = Yii::$app->request->post();
        if( $post && Yii::$app->request->isAjax ){
            $order = Order::findOne($post['order']);
            
            if( is_null($order) ) return "";

            $str = '<tr id="container-'.$order->id.'">
                <td> ORD-'.$order->id.' </td>    
                <td> '.$order->user->username.' </td>    
                <td> '.$order->table_number.' </td>    
                <td>
                    <table class="table" >
                        <tr>
                            <td style="width:15%;"> Food Name </td>
                            <td style="width:5%;"> Qty </td>                              
                        </tr>';
            foreach( $order->orderItems as $k => $val ){
                $str .= "<tr>
                    <td>".$val->food->name."</td>
                    <td>".$val->qty."</td>                           
                </tr>";
            }

            $str .='</table>
                </td>                
                <td>
                    <button id="btn-approve-'.$order->id.'"  data-id="'.$order->id.'"  class="btn-approve btn btn-success btn-flat btn-xs round">
                        <i class="fa fa-check"></i>
                    </button>
                </td>
            </tr>';

            return $str;

        }

        return "";
    }
}
